# https://github.com/jinfagang/rl-solution/blob/master/solve_cart_pole.py
import gym, random, shutil, os, socket, time#, datetime
from gym import spaces #, logger
from gym.utils import seeding
import numpy as np
from sklearn.preprocessing import QuantileTransformer, RobustScaler #, minmax_scale #, MinMaxScaler, minmax_scale #, PowerTransformer, StandardScaler, , Normalizer  # minmax_scale #,  #, 
from pathlib import Path

# from gym.envs.classic_control import rendering
# import matplotlib.pyplot as plt

# for REST
# from flask import Flask
# from flask_restful import Api, Resource, reqparse
# app = Flask(__name__)
# api = Api(app)
# api.add_resource(User, "/")
# app.run(debug=True)

if os.name == 'nt': 
    nt =True
    import win32file, win32con # for file attributes
else: nt = False

RT = not True
# RT = True

class MyrlEnv(gym.Env): # for RL
# class MyCartPoleEnv(gym.Env): 
    metadata = { 'render.modes': ['human', 'rgb_array'],
        'video.frames_per_second' : 50 }

    def __init__(self):

        sine = not True
        sine = True
        if sine: filen = '2_Sine_noise_large_rand.csv' # _rand '1_Sine.csv' '2_Sine_noise.csv' '2_Sine_noise_small.csv' 2_Sine_noise_large
        else:    filen ='EWZ_30_Min.csv'
        
        if nt: 
            pathfile = Path(r'C:\Users\Jake\py\Deep-RL-Keras')
        elif not nt and (socket.gethostname() == "BONGO" or socket.gethostname() == "Meshy"):
            pathfile = Path(r'/mnt/c/Users/Jake/py/Deep-RL-Keras')
        else: 
            pathfile = Path(r'/root/Deep-RL-Keras')

        self.data_file = (r'R:\data.csv')
        self.orders_file = (r'R:\order.csv')
        # print('================== path:', pathfile )
        file = str(pathfile / filen)
        if not RT:
            r = open('setting.txt', "r") # save csv file in test dirrr
            dirloc = Path(r.readline())
            r.close()
            shutil.copy2(str(file), str(dirloc))
            print(str(dirloc))

        self.read = np.loadtxt(file, skiprows=1 , delimiter=' ', dtype=np.float64 ) # skip first 7 rows for heading and intia bad data        
        # self.read -= self.read.min() # remove dc level and add small num to avoid devide by zero
        # read[:,1] -= read[:,1].min()
        # print( 'Min:{0:5.2f}, Max:{1:5.2f}'.format(read[:,3].min() , read[:,3].max() ) )
        # read = minmax_scale(read, feature_range=(0, 0.999), copy= False) # Normalize data -1,1. https://stackoverflow.com/questions/21030391/how-to-normalize-an-array-in-numpy
        # self.minmax = MinMaxScaler(feature_range=(-1, 1))
        self.scaler = QuantileTransformer(output_distribution='uniform') #copy=False, #sine:2.9 not good 
        qt = self.scaler.fit_transform(self.read) * 2 - 1 # important to make qt -/+, not 0/1
        self.scaler1 = RobustScaler() ; rs = self.scaler1.fit_transform(self.read) 

        if sine: # benchmark settings for sine
            # self.mul = 1
            eps = 64
            # rs = rs * 2 - 1
            self.cycle = int(1.5 * eps)#; print(self.cycle)  #65 is about 1 cycle. performence was the same even at 80

            # 0:data 1:pkwd 2:pkmd 3:pkw 4:pkm
            self.datacol = 0 ; self.data = qt[:,self.datacol]   #rs[:,0] #* 0.63 #* 2.17
            self.prevbars = int(1.5 * eps) #1 #int(2 * eps) #eps

            self.g1col = 2 ; self.g1 = qt[:,self.g1col]
            self.prevbars1 = 20 #int(2 * eps)

            self.g2col = 2 ; self.g2 = qt[:,self.g2col]
            self.prevbars2 = 0
        else:
            # self.mul = 1
            eps = 64 # 64 #110
            self.cycle = int(1.5 * eps) #135

            # 0:pkmd 1:pkwd 2:cxd 3:cxmd 4:Close 5:pkw 6:pkm 7:cx 8:rsi 9:cxd
            self.datacol = 4 ; self.data = qt[:,self.datacol]  # 4
            self.prevbars =  int(1.5 * eps) 
            
            self.g1col = 1 ; self.g1 = qt[:,self.g1col] # 1
            self.prevbars1 = 20 # 20 int(2 * eps) #250
            
            self.g2col = 0 ; self.g2 = qt[:,self.g2col]
            self.prevbars2 = 0 #int(2 * eps)

        self.maxseries = 1 * max(self.prevbars, self.prevbars1, self.prevbars2) #, self.prevbars3)
        self.X = self.maxseries - 1  # for RT, constant. can be left always on
        
        self.scale = (self.data.max() - self.data.min()) 
        print(file)#, 'Scale:{0:5.2f}, Min:{1:5.2f}, Max:{2:5.2f}'.format(self.scale, self.data.min(), self.data.max()) )
        print('data Range:{0:5.2f}, Min:{1:5.2f}, Max:{2:5.2f}'.format(self.data.max()-self.data.min(), self.data.min(), self.data.max()) )
        if self.prevbars1 > 0: print('  g1:{0:5.2f}, Min:{1:5.2f}, Max:{2:5.2f}'.format(self.g1.max()-self.g1.min(), self.g1.min(), self.g1.max()) )
        if self.prevbars2 > 0: print('  g2:{0:5.2f}, Min:{1:5.2f}, Max:{2:5.2f}'.format(self.g2.max()-self.g2.min(), self.g2.min(), self.g2.max()) )
        
        low = np.hstack((
            np.full(self.prevbars, self.data.min()),     # data/price  self.data.min()),
            np.full(self.prevbars1, self.g1.min()),      # g1
            # np.full((self.prevbars2), self.g2.min()),  # g2
            0,                                         # bar
            self.data.min()                              # buy price
            ))             
        high = np.hstack((                             
            np.full(self.prevbars, self.data.max()),     # data/price
            np.full(self.prevbars1, self.g1.max()),      # g1 
            # np.full((self.prevbars2), self.g2.max()),  # g2
            self.cycle,                             # bar
            self.data.max()                              # buy price
            ))

        self.observation_space = spaces.Box(low, high, dtype=np.float64)
        self.action_space = spaces.Discrete(3)  # noop/buy/sell
        self.reward_range = (-2.0, 2.0)
        # self.reward_range = (self.data.min()-self.data.max(), self.data.max()-self.data.min())
        self.viewer, self.state = None, None
        self.okrender = False
        self.ok_to_render = False # if okrender true will be activated after X steps
        self.bar, self.stepcount = 0, 0
        self.maximum, self.minimum = 0.0, 0.0
        # setup plot      
        self.screen_height=200 #200 # 100 dots per inch
        self.screen_width= self.cycle   #400 #64 #400 #678
        self.seed()
        #self.old = os.path.getmtime(self.data_file)

    def _get_ob(self):
        # print(self.X)
        data = self.data[self.X - self.prevbars+1:self.X+1]
        # state = np.hstack(( data, self.stepcount, self.price))
        # state = np.hstack(( data, self.price))
        g1 = self.g1[self.X - self.prevbars1+1:self.X+1]
        state = np.hstack((data, g1, self.stepcount, self.price))
        # g2 = self.g2[self.X - self.prevbars2+1:self.X+1] 
        # state = np.hstack(( data, g1, g2, self.price))
        #g3 = self.g3[self.X - self.prevbars3+1:self.X+1]
        #state = np.hstack(( data, g1, g2, g3, (self.bar, self.price)))
        # if self.bar > 45: print('self.bar ' + str(self.bar))
        # assert state.size== self.observation_space.high.size, str(state.size) + " " + str(data.size) \
            # + " " + str(g1.size) + " " + str(self.X) + " " + str(self.bar)
        return state #, dtype=np.float32)
    
    def read_data(self):
        # time.sleep(0.15)
        while True: # Wait for new data bar from WL
            time.sleep(0.07)
            fattrs = win32file.GetFileAttributes(self.data_file)
            if fattrs & win32con.FILE_ATTRIBUTE_ARCHIVE:
                win32file.SetFileAttributes(self.data_file, 128) # reset archive bit
                break
        self.read = np.loadtxt(self.data_file, skiprows=0 , delimiter=' ', dtype=np.float64 ) # skip 
        # rs = self.scaler1.fit_transform(self.read)
        qt = self.scaler.fit_transform(self.read) #  , feature_range=(-1.0, 1.0))
        # assert qt.__len__() == self.cycle, 'data.csv length must be: ' + self.cycle
        # minmax_scale(read, feature_range=(0, 0.999), copy= False)
        
        # Normalize only L/T indicators, like cxd, cxmd. Has to match reset normalization
        self.data = qt[ -self.maxseries:, self.datacol] * 2 - 1
        self.g1 = qt[ -self.maxseries:, self.g1col] * 2 - 1
        # self.g2 = self.read[ -self.maxseries:, self.g2col]
        return

    def reset(self):
        # print('bar:', self.bar)
        self.stepcount = 0
        self.bar = 0
        self.price = 0.0
        self.done, self.already_bought = False, False

        # len = self.maxseries
        # TS remarked for training speed        
        if not RT:
            self.X = random.randint( self.maxseries - 1, self.read.__len__() - self.cycle - 1)
            # self.X = 2054 # for debug
            # print(self.X)
            # Normalize window, use only for L/T indicators
            a = self.read[self.X - self.maxseries + 1 : self.X + self.cycle + 1, ]    # slice only the window from read
            # rs = self.scaler1.fit_transform(a)
            qt = self.scaler.fit_transform(a) 
            self.data = qt[ : , self.datacol] * 2 - 1    
            # self.g1 = self.read[ : , self.g1col]
            self.X = self.maxseries - 1 # -1 beacuse step adds 1 

        # print (self.data.min(), self.data.max())
        print (self.g1.min(), self.g1.max())
        # assert self.X > self.cycle and self.X < (self.data.size-self.cycle - 2), \
        #     str(self.cycle) + " " + str(self.data.size)  \
        #     + " " + str(self.maxseries)  + " " + str(self.X)
        # plot reset
        # if self.okrender and self.stepcount < 200000:  #  1000 ~= 4

        if self.ok_to_render:
            self.ax.clear()
            self.ax.set_xlim(0, self.screen_width + 3)
            # self.ax.set_ylim(self.data.min()-0.04, self.data.max()+0.04)
            self.ax.set_ylim(-1.04, 1.04)
            self.ax.axis('off')
        
        #     time.sleep(2) # give a chance to review 
        #     # wait = input("PRESS ENTER TO CONTINUE.")
        return self._get_ob()
    
    def step(self, action):     # **********************************************
        reward = 0.0 ; self.bar += 1
        
        # self.X += 1 # active only in training for speedup
        # TS remarked for training speed
        if not RT: self.X += 1
        else: 
            self.read_data() # wait for data file to update
            # if self.ok_to_render: self.ax.plot(self.bar, 0, 'c,') # for debug
            # Update orders file 
            f = open(self.orders_file, "w") ; f.writelines(str(action)) ; f.close()
        
        # reached end
        # if self.bar == self.cycle:
        #     self.done = True # for simulating end of episode
        #     reward = -1 #- self.price  # punish. otherwise it will keep going to bar limit with 0 reward.. 

        # invalid action
        # if (not self.already_bought and action == 2) or (self.already_bought and action == 1):
        #     self.done = True
            # reward = -0.01
        # #     # if self.already_bought:
        # #     #     Y = self.data[self.X]
        # #     #     reward = (Y - self.price)
        #     if self.ok_to_render: print('invalid', action, self.bar)
        
        # Buy
        if not self.already_bought and action == 1: 
            self.stepcount = 1
            self.already_bought = True
            Y = self.data[self.X]
            self.price = Y     # purchase price
            #self.price = (1 - (self.Y - self.data.min()) / self.scale )  - 0.5 
            if self.ok_to_render: 
                self.ax.plot(self.bar, Y, 'g,')
                if RT: # Update orders file 
                    f = open(self.orders_file, "w"); f.writelines(str(action)); f.close()
                    # print('buy')

        # Sell
        elif self.already_bought and action == 2:
            self.done = True
            Y = self.data[self.X]
            reward = (Y - self.price) #* self.mul
            if reward > self.maximum:   # record max reward
                self.maximum = reward
                print(' nHigh:{0:5.2f}'.format(self.maximum))
            # reward = np.clip( reward , -1.0, 1.0)

            if self.ok_to_render: 
                self.ax.plot(self.bar, Y, 'r,') 
                if RT: # Update orders file 
                    f = open(self.orders_file, "w"); f.writelines(str(action)); f.close()
                    # wait = input("PRESS ENTER TO CONTINUE.")
                    # time.sleep(3)
                    # print(' nSell:{0:5.2f}'.format(reward))
                    # print('sell')

        # Test: incentevize to exit when gaining
        elif self.already_bought: # and self.data[self.X] < self.data[self.X-1] :
            self.stepcount += 1
            if self.ok_to_render: self.ax.plot(self.bar, self.data[self.X], 'b,')
            # speed up sell
            # if self.data[self.X] > self.price and self.stepcount > 4: 
            #     reward = -0.08 #messes up the Over0 indicator, need to add filter in a2c

        elif self.ok_to_render:   # remarked for training speed, enable for rendering
            Y = self.data[self.X]
            # assert (Y >= -2 and Y <= 2)
            if self.already_bought: self.ax.plot(self.bar, Y, 'b,') 
            else: self.ax.plot(self.bar, Y, 'w,')
            if RT: 
                f = open(self.orders_file, "w")
                f.writelines('0')
                f.close()
            # self.ax.plot(self.bar, -1.9, 'c,') # for debug
            # self.ax.plot(self.bar, 1.9, 'c,') # for debug

        return self._get_ob(), reward, self.done, {"bar": self.bar} # , dtype=np.float32

    def render(self, mode='human'):
        # return# self.viewer.isopen
        # if self.ok_to_render: # render only after x steps
        if self.viewer is None:
            from gym.envs.classic_control import rendering
            import matplotlib.pyplot as plt
            # time.sleep(2.3)
            self.fig, self.ax = plt.subplots(squeeze=True)#, squeeze=True
            self.fig.set_size_inches( self.screen_width/100, self.screen_height/100)  # (w, h)
            self.fig.patch.set_facecolor('black')
            self.fig.subplots_adjust(left=0, right=1, top=1, bottom=0, wspace=0, hspace=0) # https://code.i-harness.com/en/q/8dd4b2
            self.ax.set_xlim(0, self.screen_width )
            self.ax.set_ylim(self.data.min(), self.data.max()) # padding done in reset
            self.ok_to_render = True
            self.viewer = rendering.SimpleImageViewer()
        img = self._get_image() # img is a numpy x,y,3 array, 210,160,3
        self.viewer.imshow(img) # display the breakout inital screen
        # wait = input("PRESS ENTER TO CONTINUE.")
        return self.viewer.isopen

    def _get_image(self):
        # convert matplot to numpy array rgb and crop tight
        self.fig.canvas.draw()
        # print(self.fig.canvas.get_width_height())
        buf = np.frombuffer(self.fig.canvas.tostring_rgb(), dtype=np.uint8)
        # # print(buf.shape)
        # # ncols, nrows = self.fig.canvas.get_width_height()
        img = buf.reshape((self.screen_height, self.screen_width, 3)) 
        # # data = data.reshape(fig.canvas.get_width_height()[::-1] + (3,)) https://stackoverflow.com/questions/7821518/matplotlib-save-plot-to-numpy-array
        return img

    def close(self):
        if self.viewer:
            self.viewer.close()
            self.viewer = None

    def seed(self, seed=None):
        self.np_random, seed1 = seeding.np_random(seed)
        seed2 = seeding.hash_seed(seed1 + 1) % 2**31
        return [seed1, seed2]
